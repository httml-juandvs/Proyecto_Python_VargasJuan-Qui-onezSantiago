##Programa para encontrar un Número  Divisible entre 3 y 7

for i in range(1,1000):##i será el iterador e irá hasta el 1000
    if i % 21== 0 :
        print(i)

##Desarrollado por: Juan Vargas  / T.I: 1.097.499.083